<?php

/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<!--[if lt IE 7 ]><html class="ie ie6" lang="ru"><![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="ru"><![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="ru"><![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="ru"><!--<![endif]-->
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <meta name="description" content="UBERSERVER SERVICE">
    <meta name="keywords" content="UBERSERVER SERVICE">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../images/ico/apple-touch-icon-144.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../images/ico/apple-touch-icon-114.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../images/ico/apple-touch-icon-72.png">
    <link rel="apple-touch-icon-precomposed" href="../images/ico/apple-touch-icon-57.png">
    <link rel="shortcut icon" href="../images/ico/apple-touch-icon-57.png">
    <!--[if IE]><![endif]-->
    <script src="jq/jquery.js"></script>
<!--    <script src="js/waypoints.min.js"></script>-->
<!--    <script src="js/countdown.js"></script>-->
<!--    <script src="http://maps.google.com/maps/api/js?sensor=false"></script>-->
<!--    <script src="js/gmap.js"></script>-->
<!--    <script src="js/scripts.js"></script>-->
    <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link href="/css/fontawesome.css" rel="stylesheet">
</head>



<body id="top">
<?php $this->beginBody() ?>
<div class="clearfix" class="container">

    <?php

    NavBar::begin([
        'brandLabel' => 'Uberserver',
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => [
            ['label' => 'Home', 'url' => ['/site/index']],
//	        ['label' => 'Form', 'url' => ['/site/form']],
            ['label' => 'Blog', 'url' => 'http://blog.uberserver.ru'],
            ['label' => 'Arduino', 'url' => ['/arduino']],
	        ['label' => 'About', 'url' => ['/site/about']],
            Yii::$app->user->isGuest ? ['label' => 'Вход', 'url' => ['/site/login']] : '',
            !Yii::$app->user->isGuest ? ['label' => 'Выход', 'url' => ['/site/logout']] : '',
//            Yii::$app->user->isGuest ? ['label' => 'Регистрация', 'url' => ['/site/signup']] : '',

        ],
    ]);
    NavBar::end();

    ?>

    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= $content ?>
    </div>
</div>
<hr>
<footer class="footer">
    <div class="container">
        <p class="pull-left">&copy; Uberserver <?= date('Y') ?></p>

<!--        <p class="pull-right">--><?//= Yii::powered() ?><!--</p>-->
    </div>
</footer>

<?php $this->endBody() ?>
</div>
</body>
</html>
<?php $this->endPage() ?>
