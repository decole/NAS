<?php

/* @var $this yii\web\View */

/** @var \app\models\Arduino $arduino1 */
/** @var \app\models\Arduino $arduino2 */
/** @var \app\models\Arduino $arduino3 */

/** @var \app\models\Arduino $arduino4 */

use yii\helpers\Html;

$this->title = 'Arduino';
$this->params['breadcrumbs'][] = $this->title;
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="site-contact">
    <h1><?= Html::encode($this->title) ?> Данные</h1>

    <div class="row">
        <div class="col-lg-5">
            <img src="/images/arduino/homeNike02.png" class="img-responsive" alt="Responsive image">
            <div class="sensor1"><span class="green-text">sensor: 1</span>
                <br><?= $arduino1->temperaturу; ?>  C`
                <br><?= $arduino1->humidity; ?> %</div>
            <div class="sensor2"><span class="green-text">sensor: 2</span>
                <br><?= $arduino2->temperaturу; ?> C`
                <br><?= $arduino2->humidity; ?>% </div>
            <div class="sensor3"><span class="green-text">sensor: 3</span>
                <br><?= $arduino3->temperaturу; ?>  C`
                <br><?= $arduino3->humidity; ?> %</div>
            <div class="sensor4"><span class="green-text">sensor: 4</span>
                <br><?= $arduino4->temperaturу; ?>  C`
                <br><?= $arduino4->humidity; ?> %</div>
        </div>
        <div class="col-lg-5"><img src="/images/arduino/homeNike01.png" class="img-responsive" alt="Responsive image"></div>
        <div class="col-lg-6">
            <!--                <p class="bg-primary fix-bg">Hi <span style="color: #1ABC9C;">User</span></p>-->
            <p class="fahry-box fix-bg">Сенсор 1 - <span class="green-text">go</span> <br>
                <?= $arduino1->temperaturу; ?> C`
                <?= $arduino1->humidity; ?> %
                <br>
                Дата: <?= $arduino1->date; ?>
            </p>
            <div class="none">
                <p class="fahry-box fix-bg">Сенсор 2 - <span class="red-text">stop</span> <br>
                    <?= $arduino2->temperaturу; ?> C`
                    <?= $arduino2->humidity; ?> %
                    <br>
                    Дата: <?= $arduino2->date; ?>
                </p>
                <p class="fahry-box fix-bg">Сенсор 3 - <span class="red-text">stop</span> <br>
                    <?= $arduino3->temperaturу; ?> C`
                    <?= $arduino3->humidity; ?> %
                    <br>
                    Дата: <?= $arduino3->date; ?>
                </p>
            </div>
            <p class="fahry-box fix-bg">Сенсор 4 - <span class="green-text">go</span> <br>
                <?= $arduino4->temperaturу; ?> C`
                <?= $arduino4->humidity; ?> %
                <?= $arduino4->pressure; ?> мм.Рт.ст.
                <br>
                Дата: <?= $arduino4->date; ?>
            </p>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-5">

        </div>
        <div class="col-lg-7">
            <?php
            if (!Yii::$app->user->isGuest) {
                ?>
                <div id="a1" class="arduino arduino-1-relay1 <?= $a1 ?>"><?= $a1 ?></div>
                <div id="a2" class="arduino arduino-2-relay1 <?= $a2 ?>"><?= $a2 ?></div>
                <div id="a3" class="arduino arduino-3-relay1 <?= $a3 ?>"><?= $a3 ?></div>
                <div id="a4" class="arduino arduino-4-relay1 <?= $a4 ?>"><?= $a4 ?></div>
            <?php } ?>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div id="curve_chart"></div>
        </div>
    </div>
    <?php
    if (!Yii::$app->user->isGuest) {
        ?>
        <script>
            //        $("div.arduino-1-relay1").text("<>");
            //        $("div.arduino-2-relay1").text("<>");
            //        $("div.arduino-3-relay1").text("<>");
            //        $("div.arduino-4-relay1").text("<>");
            function re(data) {
                if (data == 0) return "off";
                if (data == 1) return "on";
            }

            $(document).ready(function () {
                $("#a1").click(function () {
                    if ($("#a1").hasClass("on")) {
                        $("#a1").removeClass("on").addClass("off");
                        $.get("/api/relay?a=1&r=0", function (data) {
                            $("div.arduino-1-relay1").text(re(data));
                        });
                    }
                    else {
                        $("#a1").removeClass("off").addClass("on");
                        $.get("/api/relay?a=1&r=1", function (data) {
                            $("div.arduino-1-relay1").text(re(data));
                        });
                    }
                });

                $("#a2").click(function () {
                    if ($("#a2").hasClass("on")) {
                        $("#a2").removeClass("on").addClass("off");
                        $.get("/api/relay?a=2&r=0", function (data) {
                            $("div.arduino-2-relay1").text(re(data));
                        });
                    }
                    else {
                        $("#a2").removeClass("off").addClass("on");
                        $.get("/api/relay?a=2&r=1", function (data) {
                            $("div.arduino-2-relay1").text(re(data));
                        });
                    }
                });

                $("#a3").click(function () {
                    if ($("#a3").hasClass("on")) {
                        $("#a3").removeClass("on").addClass("off");
                        $.get("/api/relay?a=3&r=0", function (data) {
                            $("div.arduino-3-relay1").text(re(data));
                        });
                    }
                    else {
                        $("#a3").removeClass("off").addClass("on");
                        $.get("/api/relay?a=3&r=1", function (data) {
                            $("div.arduino-3-relay1").text(re(data));
                        });
                    }
                });

                $("#a4").click(function () {
                    if ($("#a4").hasClass("on")) {
                        $("#a4").removeClass("on").addClass("off");
                        $.get("/api/relay?a=4&r=0", function (data) {
                            $("div.arduino-4-relay1").text(re(data));
                        });
                    }
                    else {
                        $("#a4").removeClass("off").addClass("on");
                        $.get("/api/relay?a=4&r=1", function (data) {
                            $("div.arduino-4-relay1").text(re(data));
                        });
                    }
                });
            });
        </script>
    <?php } ?>
    <style>
        .arduino {
            display: inline-block;
            width: 60px;
            height: 60px;
            padding: 5px;
            margin: 10px;
            line-height: 45px;
            text-align: center;
            vertical-align: middle;
        }

        .arduino.on {
            background-color: #5cb85c !important;
        }

        .arduino.off {
            background-color: #843534 !important;
        }

        .none, .sensor2, .sensor3 {
            display: none;
        }
    </style>
    <script>
        $(document).ready(function () {
            function reload(){
                location.reload();
            }
            setTimeout(reload, 60000);
        });

    </script>
</div>
<div class="row">
    <div class="col-lg-6"></div>
</div>
<div class="row">
    <div id="container"></div>
</div>
<script src="https://code.highcharts.com/highcharts.src.js"></script>
<script>
    /**
     * (c) 2010-2017 Torstein Honsi
     *
     * License: www.highcharts.com/license
     *
     * Dark theme for Highcharts JS
     * @author Torstein Honsi
     */
    Highcharts.createElement('link', {
        href: 'https://fonts.googleapis.com/css?family=Unica+One',
        rel: 'stylesheet',
        type: 'text/css'
    }, null, document.getElementsByTagName('head')[0]);

    Highcharts.theme = {
        colors: ['#2b908f', '#90ee7e', '#f45b5b', '#7798BF', '#aaeeee', '#ff0066',
            '#eeaaee', '#55BF3B', '#DF5353', '#7798BF', '#aaeeee'],
        chart: {
            backgroundColor: {
                linearGradient: { x1: 0, y1: 0, x2: 1, y2: 1 },
                stops: [
                    [0, '#2a2a2b'],
                    [1, '#3e3e40']
                ]
            },
            style: {
                fontFamily: '\'Unica One\', sans-serif'
            },
            plotBorderColor: '#606063'
        },
        title: {
            style: {
                color: '#E0E0E3',
                textTransform: 'uppercase',
                fontSize: '20px'
            }
        },
        subtitle: {
            style: {
                color: '#E0E0E3',
                textTransform: 'uppercase'
            }
        },
        xAxis: {
            gridLineColor: '#707073',
            labels: {
                style: {
                    color: '#E0E0E3'
                }
            },
            lineColor: '#707073',
            minorGridLineColor: '#505053',
            tickColor: '#707073',
            title: {
                style: {
                    color: '#A0A0A3'

                }
            }
        },
        yAxis: {
            gridLineColor: '#707073',
            labels: {
                style: {
                    color: '#E0E0E3'
                }
            },
            lineColor: '#707073',
            minorGridLineColor: '#505053',
            tickColor: '#707073',
            tickWidth: 1,
            title: {
                style: {
                    color: '#A0A0A3'
                }
            }
        },
        tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.85)',
            style: {
                color: '#F0F0F0'
            }
        },
        plotOptions: {
            series: {
                dataLabels: {
                    color: '#B0B0B3'
                },
                marker: {
                    lineColor: '#333'
                }
            },
            boxplot: {
                fillColor: '#505053'
            },
            candlestick: {
                lineColor: 'white'
            },
            errorbar: {
                color: 'white'
            }
        },
        legend: {
            itemStyle: {
                color: '#E0E0E3'
            },
            itemHoverStyle: {
                color: '#FFF'
            },
            itemHiddenStyle: {
                color: '#606063'
            }
        },
        credits: {
            style: {
                color: '#666'
            }
        },
        labels: {
            style: {
                color: '#707073'
            }
        },

        drilldown: {
            activeAxisLabelStyle: {
                color: '#F0F0F3'
            },
            activeDataLabelStyle: {
                color: '#F0F0F3'
            }
        },

        navigation: {
            buttonOptions: {
                symbolStroke: '#DDDDDD',
                theme: {
                    fill: '#505053'
                }
            }
        },

        // scroll charts
        rangeSelector: {
            buttonTheme: {
                fill: '#505053',
                stroke: '#000000',
                style: {
                    color: '#CCC'
                },
                states: {
                    hover: {
                        fill: '#707073',
                        stroke: '#000000',
                        style: {
                            color: 'white'
                        }
                    },
                    select: {
                        fill: '#000003',
                        stroke: '#000000',
                        style: {
                            color: 'white'
                        }
                    }
                }
            },
            inputBoxBorderColor: '#505053',
            inputStyle: {
                backgroundColor: '#333',
                color: 'silver'
            },
            labelStyle: {
                color: 'silver'
            }
        },

        navigator: {
            handles: {
                backgroundColor: '#666',
                borderColor: '#AAA'
            },
            outlineColor: '#CCC',
            maskFill: 'rgba(255,255,255,0.1)',
            series: {
                color: '#7798BF',
                lineColor: '#A6C7ED'
            },
            xAxis: {
                gridLineColor: '#505053'
            }
        },

        scrollbar: {
            barBackgroundColor: '#808083',
            barBorderColor: '#808083',
            buttonArrowColor: '#CCC',
            buttonBackgroundColor: '#606063',
            buttonBorderColor: '#606063',
            rifleColor: '#FFF',
            trackBackgroundColor: '#404043',
            trackBorderColor: '#404043'
        },

        // special colors for some of the
        legendBackgroundColor: 'rgba(0, 0, 0, 0.5)',
        background2: '#505053',
        dataLabelsColor: '#B0B0B3',
        textColor: '#C0C0C0',
        contrastTextColor: '#F0F0F3',
        maskColor: 'rgba(255,255,255,0.3)'
    };
    <?php
    $arrayA1 = [];
    $arrayA4 = [];
    foreach($grafic as $val){
        $arrayA1[] = $val['temperaturу'];
    }
    $val='';
    foreach($grafic4 as $val){
        $arrayA4[] = $val['temperaturу'];
    }
    $val='';

    foreach($grafic as $val){
        $val['date'] = mb_substr($val['date'], 11, -3);
        //$val['date'] = str_replace(':','',$val['date']);
        $val['date'] = '\''.$val['date'].'\'';
        $arrayDate[] = $val['date'];
    }
    $arrayA1   = implode(',', $arrayA1);
    $arrayA4   = implode(',', $arrayA4);
    $arrayDate = implode(',', $arrayDate);


    ?>
    // Apply the theme
    Highcharts.setOptions(Highcharts.theme);
    Highcharts.chart('container', {
        chart: {
            type: 'line'
        },
        title: {
            text: 'Monthly Average Temperature'
        },
        subtitle: {
            text: 'Source: WorldClimate.com'
        },
        xAxis: {
            categories: [
                <?=$arrayDate;?>
            ]
        },
        yAxis: {
            title: {
                text: 'Temperature (°C)'
            }
        },
        plotOptions: {
            line: {
                dataLabels: {
                    enabled: true
                },
                enableMouseTracking: false
            }
        },
        series: [{
            name: 'Arduino 01',
            data: [
                <?=$arrayA1;?>
            ]
        }, {
            name: 'Arduino 04',
            data: [
                <?=$arrayA4;?>
            ]
        }]
    });
</script>
<hr>
<div class="row">
    <div class="col-lg-6">
        <div>
            <!-- Gismeteo informer START -->
            <link rel="stylesheet" type="text/css" href="https://nst1.gismeteo.ru/assets/flat-ui/legacy/css/informer.min.css">
            <div id="gsInformerID-ThDE2N1BwRI0IR" class="gsInformer" style="width:400px;height:181px">
                <div class="gsIContent">
                    <div id="cityLink">
                        <a href="https://www.gismeteo.ru/weather-kamyshin-5064/" target="_blank">Погода в Камышине</a>
                    </div>
                    <div class="gsLinks">
                        <table>
                            <tr>
                                <td>
                                    <div class="leftCol">
                                        <a href="https://www.gismeteo.ru/" target="_blank">
                                            <img alt="Gismeteo" title="Gismeteo" src="https://nst1.gismeteo.ru/assets/flat-ui/img/logo-mini2.png" align="middle" border="0" />
                                            <span>Gismeteo</span>
                                        </a>
                                    </div>
                                    <div class="rightCol">
                                        <a href="https://www.gismeteo.ru/weather-kamyshin-5064/2-weeks/" target="_blank">Прогноз на 2 недели</a>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <script async src="https://www.gismeteo.ru/api/informer/getinformer/?hash=ThDE2N1BwRI0IR" type="text/javascript"></script>
            <!-- Gismeteo informer END -->
        </div>
    </div>
    <div class="col-lg-6">
        <div class="accuweather">
            <p>AccuWeather Now:</p>
            <ul>
                <li class="accu">temperature: <?= /** @var \app\models\Weather $acuweather */
                    $acuweather->temperature; ?></li>
                <li class="accu">status: <?=$acuweather->spec; ?></li>
            </ul>


        </div>
    </div>
</div>