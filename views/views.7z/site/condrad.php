<p>
<?php

/** @var $obj \app\helpres\weather\WeatherInterface */

echo var_export($obj->penetrate());
?>
</p>
